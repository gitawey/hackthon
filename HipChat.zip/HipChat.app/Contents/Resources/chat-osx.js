function markMessageUnconfirmed(messageId) {
    var messageNode = document.getElementById(messageId);
    if (!messageNode || typeof messageNode == 'undefined') {
        return;
    }
    messageNode.addEventListener('mouseover', function () {
        showUnconfirmedTooltip(this, this.id);
    });
    messageNode.className = 'msgTextError messageWrapper';
}

function addChatBlock(body, insertOnTop) {
    var newDiv = document.createElement('div');
    newDiv.innerHTML = body;
    observeImages(newDiv);
    newDiv = newDiv.firstChild;
    var chatText = document.getElementById('chat_text');
    addLinkHandlers(newDiv);
    if (insertOnTop && chatText.firstChild) {
        newDiv.className += ' previousHistory';
        newDiv.style.display = 'none';
        chatText.insertBefore(newDiv, chatText.firstChild);
    } else {
        chatText.appendChild(newDiv);
    }
    replaceImageWithRetina(newDiv);
    return newDiv;
}

function showUnconfirmedTooltip(obj, messageId) {
    if (obj.className != 'msgTextError messageWrapper') {
        return;
    }
    var html = "<a href='action:resend:"+messageId+"'>This message may not have been sent successfully. Click here to attempt resend.</a>";
	showTooltip(obj, html);
}

//
// Scroll-to-chat-divider button
//

document.addEventListener('DOMContentLoaded', initScrollToChatDivider, true);

function initScrollToChatDivider() {
    var el = getScrollToChatDivider();
    if (!el) {
        el = document.createElement('div');
        el.id = 'scroll_to_chat_divider_bar';
        el.className = 'hidden';
        document.body.appendChild(el);
        el.innerHTML =
        '<div id="scroll_to_chat_divider">' +
            '<span class="aui-icon aui-icon-small aui-iconfont-up"></span>' +
            '<a id="scroll_to_chat_divider_link" href="">Jump to last read</a>' +
            '<a id="dismiss_scroll_to_chat_divider" href="">' +
                '<span class="aui-icon aui-icon-small aui-iconfont-close-dialog"></span>' +
            '</a>' +
        '</div>';
        var link = el.querySelector('#scroll_to_chat_divider_link');
        link.addEventListener('click', doScrollToChatDivider);
        var dismiss = el.querySelector('#dismiss_scroll_to_chat_divider');
        dismiss.addEventListener('click', dismissScrollToChatDivider);
    }

    window.addEventListener('chat-divider-added', onAddChatDivider);
    window.addEventListener('chat-divider-removed', onRemoveChatDivider);
    window.addEventListener('chat-active-state-updated', onChatActiveStateUpdated);
    window.addEventListener('load', function () {
        // when a tab with several unread messages first loads its webview,
        // we need to give the view a little time to load and layout that content
        // before trying to update the scroll to chat button; the exact timeout
        // value may need some tweaking
        setTimeout(function () {
           window.hasShownScrollToChatDivider = false;
           updateScrollToChatDivider();
        }, 1000);
    });

    var viewport = getViewport();
    viewport.addEventListener('scroll', updateScrollToChatDivider);
}

function onAddChatDivider() {
    window.hasShownScrollToChatDivider = false;
    updateScrollToChatDivider();
}

function onRemoveChatDivider() {
    hideScrollToChatDivider();
}

function onChatActiveStateUpdated(e) {
    updateScrollToChatDivider();
    if (e.detail.isActive) {
        // setting this on show will prevent the scroll btn from showing
        // for any reason after this web view is made the active chat
        window.hasShownScrollToChatDivider = true;
    }
}

function updateScrollToChatDivider() {
    if (!window.osxConnector.isScrollToUnreadDividerEnabled()) {
        hideScrollToChatDivider();
        return;
    }
    var divider = getChatDivider();
    if (!divider) return;
    if (isBelowViewport(divider)) {
        // suppress displaying the scroll to divider ui if the divider is added
        // when the chat panel is scrolled back in read history
        window.hasShownScrollToChatDivider = true;
        return;
    }
    if (!window.hasShownScrollToChatDivider && isAboveViewport(divider)) {
        showScrollToChatDivider();
        window.hasShownScrollToChatDivider = true;
        return;
    }
    if (!isAboveViewport(divider)) {
        hideScrollToChatDivider();
        return;
    }
}

function showScrollToChatDivider() {
    var el = getScrollToChatDivider();
    el.className = 'visible';
}

function getScrollToChatDivider() {
    return document.getElementById('scroll_to_chat_divider_bar');
}

function hideScrollToChatDivider() {
    var el = getScrollToChatDivider();
    el.className = 'hidden';
}

function doScrollToChatDivider(e) {
    e.preventDefault();
    var divider = getChatDivider();
    if (divider) {
        var viewport = getViewport();
        var y = viewport.scrollTop + divider.getBoundingClientRect().top;
        scrollToAnimated(y, 200, easeInOutCubic, hideScrollToChatDivider);
    }
}

function easeInOutCubic(t) {
    return t<.5 ? 4*t*t*t : (t-1)*(2*t-2)*(2*t-2)+1;
}

function dismissScrollToChatDivider(e) {
    e.preventDefault();
    hideScrollToChatDivider();
}

function isAboveViewport(element) {
    var rect = element.getBoundingClientRect();
    return rect.bottom < 0;
}

function isBelowViewport(element) {
    var rect = element.getBoundingClientRect();
    return rect.top > window.innerHeight;
}

function getViewport() {
    return document.querySelector('#viewport');
}

//
// Viewport scrolling
//

function doScroll() {
    var viewport = getViewport();
    viewport.scrollTop = viewport.scrollHeight;
}

function scrollByPixels(numPixels) {
    setTimeout(function () {
       var viewport = getViewport();
       viewport.scrollTop += numPixels;
   }, 100);
}

function scrollAtBottom() {
    return window.lastScrollPosition === "bottom";
}

function scrollToBottom() {
    setTimeout(doScroll, 200);
}

function scrollToAnimated(y, duration, easingFunction, callback) {
    callback = callback || function () {};
    var start = Date.now();
    var elem = getViewport();
    var from = elem.scrollTop;
    if (from === y) {
        callback();
        return;
    }
    function scroll(timestamp) {
        var currentTime = Date.now();
        var time = Math.min(1, ((currentTime - start) / duration));
        var easedT = easingFunction(time);
        elem.scrollTop = (easedT * (y - from)) + from;
        if (time < 1) requestAnimationFrame(scroll);
        else if (callback) callback();
    }
    requestAnimationFrame(scroll);
}

window.lastScrollPosition = "bottom";

function onViewportScrolled(e) {
    var viewport = getViewport();
    if (!viewport) return;
    var position;
    var chat = document.querySelector('#chat_text');
    var chatRect = chat.getBoundingClientRect();
    var stateMessage = getChatStateMessage();
    var stateMessageHeight = stateMessage.clientHeight;
    if (stateMessageHeight + chat.clientHeight + chatRect.top === viewport.clientHeight) {
        position = "bottom";
    } else if (chatRect.top === 0) {
        position = "top";
    } else {
        position = "interior";
    }
    window.lastScrollPosition = position;
    window.osxConnector.viewportScrolled_(position);
}

// watches the height of the chat div for a short time after adding chats
// containing images so that scroll position can be updated shortly after
// the browser knows the image height, but potentially before the image is
// fully loaded -- this gets the viewport-based scrolling system close to
// the old native scrolling method in terms of staying up to date
function watchChatHeight() {
    var watchDuration = 5000;
    var watcher = window.chatHeightWatcher = window.chatHeightWatcher || {};
    if (watcher.expiry > 0) {
        watcher.expiry = Date.now() + watchDuration;
        return;
    }
    var chat = document.querySelector('#chat_text');
    function tick() {
        if (watcher.expiry <= Date.now()) {
            clearInterval(watcher.interval);
            delete window.chatHeightWatcher;
            return;
        }
        var height = chat.clientHeight;
        if (height != watcher.height) {
            checkNeedsScroll();
        }
        watcher.height = height;
    }
    watcher.expiry = Date.now() + watchDuration;
    watcher.interval = setInterval(tick, 100);
    tick();
}

window.addEventListener('chat-image-observed', watchChatHeight);

window.addEventListener('load', function () {
    var viewport = getViewport();
    viewport.addEventListener('scroll', onViewportScrolled);
});

function scrollPageUp() {
    var viewport = getViewport();
    var y = viewport.scrollTop - viewport.clientHeight;
    scrollToAnimated(y, 200, easeInOutCubic);
}

function scrollPageDown() {
    var viewport = getViewport();
    var y = viewport.scrollTop + viewport.clientHeight;
    scrollToAnimated(y, 200, easeInOutCubic);
}
