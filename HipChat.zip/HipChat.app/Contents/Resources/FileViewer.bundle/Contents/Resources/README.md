# Howto

Ensure you've got [Bower](http://bower.io) installed.

`
bower --version
`

then clone this Repo, do a bower install and open up `index.html`.

`
git clone git@bitbucket.org:mkida/atlassian-fileviewer-example.git && cd atlassian-fileviewer-example && bower install && open index.html
`