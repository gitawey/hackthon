#!/bin/bash

BCFV="./bower_components/atlassian-fileviewer"

rm -rf $BCFV/docs $BCFV/examples $BCFV/lib $BCFV/test $BCFV/vendor/pdfjs
rm $BCFV/CHANGELOG.md
rm $BCFV/Gruntfile.js

rm $BCFV/dist/fileviewer-*
rm $BCFV/dist/fileviewer.js
