var imagePreviewOpened = 'arrow_drawer@2x.png';
var imagePreviewClosed = 'arrow_drawer_down@2x.png';

document.addEventListener('DOMContentLoaded', init);

function init(){
    document.addEventListener("click",
                              function (){ setTimeout(handleBodyClick, 0);});
    document.getElementById("tooltip").addEventListener("click",
                                                        function() {event.target.style.visibility = "hidden";});

    setupDOMObserver();
}

function setupDOMObserver(){
    //console.log("content ready");
    var observer = new MutationObserver(
                                    function(mutations, observer) {
                                        // fired when a mutation occurs
                                        var i,j;
                                        for (i=0; i<mutations.length; i++){
                                            for (j=0; j<mutations[i].addedNodes.length; j++){
                                                processNode(mutations[i].addedNodes[j]);
                                            }
                                        }
                                    }
    );

    //console.log(document.getElementById("chat_text"));
    observer.observe(document.getElementById("chat_text"), {
                     subtree: true,     // observe changes to #chat_text and its subtree
                     childList: true    // we're only interested in childList changes (addition of child nodes)
                 });
}

function processNode(node){
    bindEventListeners(node, "checkNeedsScroll", "load", function() { checkNeedsScroll(); });
    bindEventListeners(node, "onclickToggle", "click", function() { toggleImage(event.target); });
    bindEventListeners(node, "showMentionTooltip", "mouseover",
                       function() {
                       showMentionTooltip(event.target);
                       });
}

function bindEventListeners(node, className, eventName, callback){
    elements = node.getElementsByClassName(className);
    for (i=0; i<elements.length; i++){
        elements[i].addEventListener(eventName, callback);
    }
}
